"use client"

interface MonthlyTrendChartProps {
  data: Array<{
    month: string
    income: number
    expenses: number
    savings: number
  }>
}

export function MonthlyTrendChart({ data }: MonthlyTrendChartProps) {
  const maxValue = Math.max(...data.flatMap((d) => [d.income, d.expenses, d.savings]))

  return (
    <div className="space-y-4">
      <div className="flex items-end space-x-4 h-64">
        {data.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center space-y-1">
            <div className="flex items-end space-x-1 w-full h-48">
              {/* Income Bar */}
              <div className="flex-1 flex flex-col items-center">
                <div
                  className="w-full bg-green-500 rounded-t"
                  style={{
                    height: `${(item.income / maxValue) * 100}%`,
                    minHeight: "4px",
                  }}
                  title={`Income: $${item.income}`}
                />
              </div>

              {/* Expenses Bar */}
              <div className="flex-1 flex flex-col items-center">
                <div
                  className="w-full bg-red-500 rounded-t"
                  style={{
                    height: `${(item.expenses / maxValue) * 100}%`,
                    minHeight: "4px",
                  }}
                  title={`Expenses: $${item.expenses}`}
                />
              </div>

              {/* Savings Bar */}
              <div className="flex-1 flex flex-col items-center">
                <div
                  className="w-full bg-blue-500 rounded-t"
                  style={{
                    height: `${(item.savings / maxValue) * 100}%`,
                    minHeight: "4px",
                  }}
                  title={`Savings: $${item.savings}`}
                />
              </div>
            </div>

            <span className="text-xs text-gray-500 font-medium">{item.month}</span>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex justify-center space-x-6">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded" />
          <span className="text-sm">Income</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-500 rounded" />
          <span className="text-sm">Expenses</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-blue-500 rounded" />
          <span className="text-sm">Savings</span>
        </div>
      </div>
    </div>
  )
}
