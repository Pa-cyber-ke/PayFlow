"use client"

interface CategoryChartProps {
  data: Array<{
    category: string
    amount: number
    percentage: number
    color: string
  }>
}

export function CategoryChart({ data }: CategoryChartProps) {
  const total = data.reduce((sum, item) => sum + item.amount, 0)

  return (
    <div className="space-y-4">
      {/* Donut Chart Simulation */}
      <div className="relative w-48 h-48 mx-auto">
        <div className="w-full h-full rounded-full border-8 border-gray-200 relative overflow-hidden">
          {data.map((item, index) => {
            const percentage = (item.amount / total) * 100
            const rotation = data.slice(0, index).reduce((sum, prev) => sum + (prev.amount / total) * 360, 0)

            return (
              <div
                key={item.category}
                className="absolute inset-0 rounded-full"
                style={{
                  background: `conic-gradient(from ${rotation}deg, ${item.color} 0deg, ${item.color} ${percentage * 3.6}deg, transparent ${percentage * 3.6}deg)`,
                }}
              />
            )
          })}
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center">
            <div className="text-center">
              <div className="text-lg font-bold">${total}</div>
              <div className="text-xs text-gray-500">Total</div>
            </div>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="space-y-2">
        {data.map((item) => (
          <div key={item.category} className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-sm">{item.category}</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium">${item.amount}</div>
              <div className="text-xs text-gray-500">{item.percentage}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
