"use client"

import { useEffect, useState } from "react"

interface SpendingChartProps {
  timeRange: string
}

export function SpendingChart({ timeRange }: SpendingChartProps) {
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    // Generate sample data based on time range
    const generateData = () => {
      const days = Number.parseInt(timeRange)
      const data = []

      for (let i = days - 1; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)

        data.push({
          date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
          amount: Math.floor(Math.random() * 200) + 50,
        })
      }

      setChartData(data)
    }

    generateData()
  }, [timeRange])

  const maxAmount = Math.max(...chartData.map((d) => d.amount))

  return (
    <div className="space-y-4">
      <div className="flex items-end space-x-1 h-48">
        {chartData.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center">
            <div
              className="w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600"
              style={{
                height: `${(item.amount / maxAmount) * 100}%`,
                minHeight: "4px",
              }}
              title={`$${item.amount} on ${item.date}`}
            />
            <span className="text-xs text-gray-500 mt-2 transform -rotate-45 origin-left">{item.date}</span>
          </div>
        ))}
      </div>
      <div className="text-center text-sm text-gray-600">Daily spending over the last {timeRange} days</div>
    </div>
  )
}
