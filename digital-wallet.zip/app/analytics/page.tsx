"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, CreditCard, TrendingUp, TrendingDown, BarChart3, PieChart } from "lucide-react"
import { SpendingChart } from "@/components/spending-chart"
import { CategoryChart } from "@/components/category-chart"
import { MonthlyTrendChart } from "@/components/monthly-trend-chart"

interface SpendingData {
  category: string
  amount: number
  percentage: number
  color: string
}

interface MonthlyData {
  month: string
  income: number
  expenses: number
  savings: number
}

export default function AnalyticsPage() {
  const [user, setUser] = useState<any>(null)
  const [timeRange, setTimeRange] = useState("30")
  const [spendingData, setSpendingData] = useState<SpendingData[]>([])
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([])
  const [insights, setInsights] = useState<any>({})
  const router = useRouter()

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Generate sample analytics data
    generateAnalyticsData(userData.id)
  }, [router, timeRange])

  const generateAnalyticsData = (userId: string) => {
    // Sample spending data by category
    const sampleSpendingData: SpendingData[] = [
      { category: "Food & Dining", amount: 450, percentage: 35, color: "#EF4444" },
      { category: "Transportation", amount: 280, percentage: 22, color: "#3B82F6" },
      { category: "Shopping", amount: 320, percentage: 25, color: "#EC4899" },
      { category: "Entertainment", amount: 150, percentage: 12, color: "#8B5CF6" },
      { category: "Healthcare", amount: 80, percentage: 6, color: "#10B981" },
    ]

    // Sample monthly trend data
    const sampleMonthlyData: MonthlyData[] = [
      { month: "Jan", income: 3500, expenses: 2800, savings: 700 },
      { month: "Feb", income: 3500, expenses: 2650, savings: 850 },
      { month: "Mar", income: 3700, expenses: 2900, savings: 800 },
      { month: "Apr", income: 3500, expenses: 2750, savings: 750 },
      { month: "May", income: 3600, expenses: 2850, savings: 750 },
      { month: "Jun", income: 3500, expenses: 2600, savings: 900 },
    ]

    setSpendingData(sampleSpendingData)
    setMonthlyData(sampleMonthlyData)

    // Generate insights
    const totalSpent = sampleSpendingData.reduce((sum, item) => sum + item.amount, 0)
    const topCategory = sampleSpendingData.reduce((prev, current) => (prev.amount > current.amount ? prev : current))
    const avgMonthlyExpenses =
      sampleMonthlyData.reduce((sum, month) => sum + month.expenses, 0) / sampleMonthlyData.length
    const avgMonthlySavings =
      sampleMonthlyData.reduce((sum, month) => sum + month.savings, 0) / sampleMonthlyData.length

    setInsights({
      totalSpent,
      topCategory: topCategory.category,
      avgMonthlyExpenses,
      avgMonthlySavings,
      savingsRate: (avgMonthlySavings / (avgMonthlyExpenses + avgMonthlySavings)) * 100,
    })
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Header with Time Range Selector */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Financial Analytics</h1>
              <p className="text-gray-600">Insights into your spending patterns and financial health</p>
            </div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 3 months</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Spent</p>
                    <p className="text-2xl font-bold">${insights.totalSpent?.toFixed(2)}</p>
                  </div>
                  <TrendingDown className="w-8 h-8 text-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Avg Monthly Expenses</p>
                    <p className="text-2xl font-bold">${insights.avgMonthlyExpenses?.toFixed(2)}</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Avg Monthly Savings</p>
                    <p className="text-2xl font-bold">${insights.avgMonthlySavings?.toFixed(2)}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Savings Rate</p>
                    <p className="text-2xl font-bold">{insights.savingsRate?.toFixed(1)}%</p>
                  </div>
                  <PieChart className="w-8 h-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Spending by Category */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="w-5 h-5 mr-2" />
                  Spending by Category
                </CardTitle>
                <CardDescription>Your expense breakdown for the selected period</CardDescription>
              </CardHeader>
              <CardContent>
                <CategoryChart data={spendingData} />
              </CardContent>
            </Card>

            {/* Daily Spending Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Daily Spending Trend
                </CardTitle>
                <CardDescription>Your spending pattern over time</CardDescription>
              </CardHeader>
              <CardContent>
                <SpendingChart timeRange={timeRange} />
              </CardContent>
            </Card>
          </div>

          {/* Monthly Trend */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Monthly Financial Trend
              </CardTitle>
              <CardDescription>Income, expenses, and savings over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <MonthlyTrendChart data={monthlyData} />
            </CardContent>
          </Card>

          {/* Financial Insights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Spending Insights</CardTitle>
                <CardDescription>AI-powered analysis of your spending habits</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-800">Top Spending Category</h4>
                  <p className="text-sm text-blue-600">
                    You spend the most on <strong>{insights.topCategory}</strong>. Consider setting a stricter budget
                    for this category.
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-800">Savings Performance</h4>
                  <p className="text-sm text-green-600">
                    Your savings rate of {insights.savingsRate?.toFixed(1)}% is{" "}
                    {insights.savingsRate > 20 ? "excellent" : "good"}!
                    {insights.savingsRate < 20 && " Try to aim for 20% or higher."}
                  </p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <h4 className="font-medium text-yellow-800">Budget Recommendation</h4>
                  <p className="text-sm text-yellow-600">
                    Based on your spending patterns, consider allocating 50% for needs, 30% for wants, and 20% for
                    savings.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Financial Health Score</CardTitle>
                <CardDescription>Overall assessment of your financial wellness</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-6">
                  <div className="text-4xl font-bold text-green-600 mb-2">78/100</div>
                  <p className="text-gray-600">Good Financial Health</p>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Savings Rate</span>
                    <span className="text-sm font-medium text-green-600">Excellent</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Budget Adherence</span>
                    <span className="text-sm font-medium text-yellow-600">Good</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Spending Consistency</span>
                    <span className="text-sm font-medium text-green-600">Very Good</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Emergency Fund</span>
                    <span className="text-sm font-medium text-red-600">Needs Improvement</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
