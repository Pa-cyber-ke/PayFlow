"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Download, CreditCard, Copy, QrCode, Share } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  accountNumber: string
  balance: number
  createdAt: string
}

export default function ReceiveMoneyPage() {
  const [user, setUser] = useState<User | null>(null)
  const [requestAmount, setRequestAmount] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  const copyAccountNumber = () => {
    if (user) {
      navigator.clipboard.writeText(user.accountNumber)
      toast({
        title: "Copied!",
        description: "Account number copied to clipboard",
      })
    }
  }

  const sharePaymentLink = () => {
    if (user) {
      const message = `Send me money on PayFlow! My account number is: ${user.accountNumber}`
      if (navigator.share) {
        navigator.share({
          title: "PayFlow Payment Request",
          text: message,
        })
      } else {
        navigator.clipboard.writeText(message)
        toast({
          title: "Copied!",
          description: "Payment request copied to clipboard",
        })
      }
    }
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto space-y-6">
          {/* Account Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="w-5 h-5 mr-2" />
                Receive Money
              </CardTitle>
              <CardDescription>Share your account details to receive payments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center p-6 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-lg">
                <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-xl">
                    {user.firstName[0]}
                    {user.lastName[0]}
                  </span>
                </div>
                <h3 className="font-semibold text-lg">
                  {user.firstName} {user.lastName}
                </h3>
                <p className="text-gray-600 text-sm">{user.email}</p>
              </div>

              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Account Number</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Input value={user.accountNumber} readOnly className="font-mono" />
                    <Button variant="outline" size="sm" onClick={copyAccountNumber}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <Button onClick={sharePaymentLink} className="w-full bg-transparent" variant="outline">
                  <Share className="w-4 h-4 mr-2" />
                  Share Payment Details
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Request Specific Amount */}
          <Card>
            <CardHeader>
              <CardTitle>Request Specific Amount</CardTitle>
              <CardDescription>Create a payment request for a specific amount</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  placeholder="0.00"
                  value={requestAmount}
                  onChange={(e) => setRequestAmount(e.target.value)}
                />
              </div>

              {requestAmount && (
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800 mb-2">
                    <strong>Payment Request:</strong>
                  </p>
                  <p className="text-sm text-green-700">
                    Please send ${Number.parseFloat(requestAmount).toFixed(2)} to account {user.accountNumber}
                  </p>
                </div>
              )}

              <Button
                onClick={() => {
                  if (requestAmount) {
                    const message = `Please send me $${Number.parseFloat(requestAmount).toFixed(2)} on PayFlow. My account number is: ${user.accountNumber}`
                    if (navigator.share) {
                      navigator.share({
                        title: "PayFlow Payment Request",
                        text: message,
                      })
                    } else {
                      navigator.clipboard.writeText(message)
                      toast({
                        title: "Copied!",
                        description: "Payment request copied to clipboard",
                      })
                    }
                  }
                }}
                className="w-full"
                disabled={!requestAmount}
              >
                Share Payment Request
              </Button>
            </CardContent>
          </Card>

          {/* QR Code Placeholder */}
          <Card>
            <CardHeader>
              <CardTitle>QR Code</CardTitle>
              <CardDescription>Let others scan to send you money</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center p-8 bg-gray-100 rounded-lg">
                <QrCode className="w-24 h-24 text-gray-400 mb-4" />
                <p className="text-sm text-gray-600 text-center">QR code for account {user.accountNumber}</p>
                <p className="text-xs text-gray-500 mt-2">(QR code generation would be implemented in production)</p>
              </div>
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>How to Receive Money</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-indigo-600 text-xs font-bold">1</span>
                  </div>
                  <p>Share your account number with the sender</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-indigo-600 text-xs font-bold">2</span>
                  </div>
                  <p>They enter your account number in their PayFlow app</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-indigo-600 text-xs font-bold">3</span>
                  </div>
                  <p>Money is transferred instantly to your account</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
