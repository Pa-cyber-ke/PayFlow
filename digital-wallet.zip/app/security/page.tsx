"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, CreditCard, Shield, Fingerprint, Smartphone, Lock, Eye, EyeOff } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function SecurityPage() {
  const [user, setUser] = useState<any>(null)
  const [pinData, setPinData] = useState({
    currentPin: "",
    newPin: "",
    confirmPin: "",
  })
  const [showPins, setShowPins] = useState(false)
  const [securitySettings, setSecuritySettings] = useState({
    biometricEnabled: false,
    twoFactorEnabled: false,
    loginNotifications: true,
    transactionAlerts: true,
    fraudDetection: true,
  })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load security settings
    const savedSettings = localStorage.getItem(`security_${userData.id}`)
    if (savedSettings) {
      setSecuritySettings(JSON.parse(savedSettings))
    }
  }, [router])

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    if (pinData.newPin !== pinData.confirmPin) {
      toast({
        title: "Error",
        description: "New PIN and confirmation don't match",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    if (pinData.newPin.length !== 4) {
      toast({
        title: "Error",
        description: "PIN must be exactly 4 digits",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Save PIN (in production, this would be hashed)
    localStorage.setItem(`pin_${user.id}`, pinData.newPin)

    toast({
      title: "PIN Updated",
      description: "Your transaction PIN has been set successfully",
    })

    setPinData({ currentPin: "", newPin: "", confirmPin: "" })
    setIsLoading(false)
  }

  const handleSecurityToggle = (setting: string, value: boolean) => {
    const newSettings = { ...securitySettings, [setting]: value }
    setSecuritySettings(newSettings)
    localStorage.setItem(`security_${user.id}`, JSON.stringify(newSettings))

    toast({
      title: "Security Setting Updated",
      description: `${setting.replace(/([A-Z])/g, " $1").toLowerCase()} has been ${value ? "enabled" : "disabled"}`,
    })
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* PIN Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="w-5 h-5 mr-2" />
                Transaction PIN
              </CardTitle>
              <CardDescription>Set up a 4-digit PIN for secure transactions</CardDescription>
            </CardHeader>
            <form onSubmit={handlePinSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newPin">New PIN</Label>
                  <div className="relative">
                    <Input
                      id="newPin"
                      type={showPins ? "text" : "password"}
                      maxLength={4}
                      pattern="[0-9]{4}"
                      placeholder="Enter 4-digit PIN"
                      value={pinData.newPin}
                      onChange={(e) => setPinData({ ...pinData, newPin: e.target.value.replace(/\D/g, "") })}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3"
                      onClick={() => setShowPins(!showPins)}
                    >
                      {showPins ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPin">Confirm PIN</Label>
                  <Input
                    id="confirmPin"
                    type={showPins ? "text" : "password"}
                    maxLength={4}
                    pattern="[0-9]{4}"
                    placeholder="Confirm 4-digit PIN"
                    value={pinData.confirmPin}
                    onChange={(e) => setPinData({ ...pinData, confirmPin: e.target.value.replace(/\D/g, "") })}
                  />
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Setting PIN..." : "Set PIN"}
                </Button>
              </CardContent>
            </form>
          </Card>

          {/* Security Features */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Security Features
              </CardTitle>
              <CardDescription>Configure your account security preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Fingerprint className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium">Biometric Authentication</p>
                    <p className="text-sm text-gray-600">Use fingerprint or face ID for login</p>
                  </div>
                </div>
                <Switch
                  checked={securitySettings.biometricEnabled}
                  onCheckedChange={(checked) => handleSecurityToggle("biometricEnabled", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Smartphone className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium">Two-Factor Authentication</p>
                    <p className="text-sm text-gray-600">SMS verification for sensitive actions</p>
                  </div>
                </div>
                <Switch
                  checked={securitySettings.twoFactorEnabled}
                  onCheckedChange={(checked) => handleSecurityToggle("twoFactorEnabled", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium">Fraud Detection</p>
                    <p className="text-sm text-gray-600">Automatic monitoring for suspicious activity</p>
                  </div>
                </div>
                <Switch
                  checked={securitySettings.fraudDetection}
                  onCheckedChange={(checked) => handleSecurityToggle("fraudDetection", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Lock className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium">Login Notifications</p>
                    <p className="text-sm text-gray-600">Get notified of new device logins</p>
                  </div>
                </div>
                <Switch
                  checked={securitySettings.loginNotifications}
                  onCheckedChange={(checked) => handleSecurityToggle("loginNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <CreditCard className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium">Transaction Alerts</p>
                    <p className="text-sm text-gray-600">Instant notifications for all transactions</p>
                  </div>
                </div>
                <Switch
                  checked={securitySettings.transactionAlerts}
                  onCheckedChange={(checked) => handleSecurityToggle("transactionAlerts", checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Security Status */}
          <Card>
            <CardHeader>
              <CardTitle>Security Status</CardTitle>
              <CardDescription>Your account security overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <span className="text-green-800">Account Verification</span>
                  <span className="text-green-600 font-medium">Verified ✓</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <span className="text-green-800">Email Verification</span>
                  <span className="text-green-600 font-medium">Verified ✓</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <span className="text-blue-800">Security Score</span>
                  <span className="text-blue-600 font-medium">85/100</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
