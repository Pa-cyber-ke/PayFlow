"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Send, CreditCard } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  accountNumber: string
  balance: number
  createdAt: string
}

export default function SendMoneyPage() {
  const [user, setUser] = useState<User | null>(null)
  const [formData, setFormData] = useState({
    recipientAccount: "",
    amount: "",
    description: "",
    category: "",
    pin: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsLoading(true)

    const amount = Number.parseFloat(formData.amount)

    // Validation
    if (amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    if (amount > user.balance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough money to complete this transaction",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    if (formData.recipientAccount === user.accountNumber) {
      toast({
        title: "Error",
        description: "You cannot send money to yourself",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Check if recipient exists
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const recipient = users.find((u: User) => u.accountNumber === formData.recipientAccount)

    if (!recipient) {
      toast({
        title: "Recipient Not Found",
        description: "The account number you entered does not exist",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Verify PIN
    const savedPin = localStorage.getItem(`pin_${user.id}`)
    if (savedPin && formData.pin !== savedPin) {
      toast({
        title: "Invalid PIN",
        description: "Please enter your correct transaction PIN",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Create transaction
    const transaction = {
      id: Date.now().toString(),
      type: "sent" as const,
      amount,
      fromAccount: user.accountNumber,
      toAccount: formData.recipientAccount,
      description: formData.description || "Money transfer",
      category: formData.category,
      timestamp: new Date().toISOString(),
      status: "completed" as const,
    }

    // Update balances
    const updatedUser = { ...user, balance: user.balance - amount }
    const updatedRecipient = { ...recipient, balance: recipient.balance + amount }

    // Update users array
    const updatedUsers = users.map((u: User) => {
      if (u.accountNumber === user.accountNumber) return updatedUser
      if (u.accountNumber === recipient.accountNumber) return updatedRecipient
      return u
    })

    // Save to localStorage
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    // Add transaction
    const transactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    transactions.push(transaction)
    localStorage.setItem("transactions", JSON.stringify(transactions))

    toast({
      title: "Money Sent Successfully!",
      description: `$${amount.toFixed(2)} sent to ${formData.recipientAccount}`,
    })

    setTimeout(() => {
      router.push("/dashboard")
    }, 2000)

    setIsLoading(false)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Send className="w-5 h-5 mr-2" />
                Send Money
              </CardTitle>
              <CardDescription>Transfer money to another PayFlow account</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Available Balance:</strong> ${user.balance.toFixed(2)}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recipientAccount">Recipient Account Number</Label>
                  <Input
                    id="recipientAccount"
                    type="text"
                    placeholder="Enter 10-digit account number"
                    required
                    value={formData.recipientAccount}
                    onChange={(e) => setFormData({ ...formData, recipientAccount: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">Amount ($)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    required
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="food">Food & Dining</SelectItem>
                      <SelectItem value="transport">Transportation</SelectItem>
                      <SelectItem value="shopping">Shopping</SelectItem>
                      <SelectItem value="entertainment">Entertainment</SelectItem>
                      <SelectItem value="bills">Bills & Utilities</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="What's this payment for?"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pin">Transaction PIN</Label>
                  <Input
                    id="pin"
                    type="password"
                    maxLength={4}
                    placeholder="Enter 4-digit PIN"
                    value={formData.pin}
                    onChange={(e) => setFormData({ ...formData, pin: e.target.value.replace(/\D/g, "") })}
                  />
                </div>

                {formData.amount && (
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium mb-2">Transaction Summary</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Amount:</span>
                        <span>${Number.parseFloat(formData.amount || "0").toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Fee:</span>
                        <span>$0.00</span>
                      </div>
                      <div className="flex justify-between font-medium border-t pt-1">
                        <span>Total:</span>
                        <span>${Number.parseFloat(formData.amount || "0").toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Sending..." : "Send Money"}
                </Button>
              </CardContent>
            </form>
          </Card>
        </div>
      </div>
    </div>
  )
}
