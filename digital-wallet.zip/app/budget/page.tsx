"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, CreditCard, Target, Plus, Edit, Trash2, TrendingUp } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface BudgetCategory {
  id: string
  name: string
  limit: number
  spent: number
  color: string
  icon: string
}

interface FinancialGoal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  category: string
}

export default function BudgetPage() {
  const [user, setUser] = useState<any>(null)
  const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([])
  const [financialGoals, setFinancialGoals] = useState<FinancialGoal[]>([])
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [showAddGoal, setShowAddGoal] = useState(false)
  const [newCategory, setNewCategory] = useState({
    name: "",
    limit: "",
    color: "#3B82F6",
    icon: "💰",
  })
  const [newGoal, setNewGoal] = useState({
    name: "",
    targetAmount: "",
    deadline: "",
    category: "savings",
  })
  const router = useRouter()
  const { toast } = useToast()

  const categoryIcons = ["💰", "🍔", "🚗", "🏠", "🎬", "👕", "💊", "📚", "✈️", "🎮"]
  const categoryColors = ["#3B82F6", "#EF4444", "#10B981", "#F59E0B", "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"]

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load budget data
    const savedBudgets = localStorage.getItem(`budgets_${userData.id}`)
    if (savedBudgets) {
      setBudgetCategories(JSON.parse(savedBudgets))
    } else {
      // Default categories
      const defaultCategories = [
        { id: "1", name: "Food & Dining", limit: 500, spent: 320, color: "#EF4444", icon: "🍔" },
        { id: "2", name: "Transportation", limit: 300, spent: 180, color: "#3B82F6", icon: "🚗" },
        { id: "3", name: "Entertainment", limit: 200, spent: 95, color: "#8B5CF6", icon: "🎬" },
        { id: "4", name: "Shopping", limit: 400, spent: 250, color: "#EC4899", icon: "👕" },
      ]
      setBudgetCategories(defaultCategories)
      localStorage.setItem(`budgets_${userData.id}`, JSON.stringify(defaultCategories))
    }

    // Load financial goals
    const savedGoals = localStorage.getItem(`goals_${userData.id}`)
    if (savedGoals) {
      setFinancialGoals(JSON.parse(savedGoals))
    } else {
      // Default goals
      const defaultGoals = [
        {
          id: "1",
          name: "Emergency Fund",
          targetAmount: 5000,
          currentAmount: 2500,
          deadline: "2024-12-31",
          category: "savings",
        },
        {
          id: "2",
          name: "Vacation Fund",
          targetAmount: 2000,
          currentAmount: 800,
          deadline: "2024-08-15",
          category: "travel",
        },
      ]
      setFinancialGoals(defaultGoals)
      localStorage.setItem(`goals_${userData.id}`, JSON.stringify(defaultGoals))
    }
  }, [router])

  const addCategory = () => {
    if (!newCategory.name || !newCategory.limit) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    const category: BudgetCategory = {
      id: Date.now().toString(),
      name: newCategory.name,
      limit: Number.parseFloat(newCategory.limit),
      spent: 0,
      color: newCategory.color,
      icon: newCategory.icon,
    }

    const updatedCategories = [...budgetCategories, category]
    setBudgetCategories(updatedCategories)
    localStorage.setItem(`budgets_${user.id}`, JSON.stringify(updatedCategories))

    setNewCategory({ name: "", limit: "", color: "#3B82F6", icon: "💰" })
    setShowAddCategory(false)

    toast({
      title: "Category Added",
      description: "New budget category created successfully",
    })
  }

  const addGoal = () => {
    if (!newGoal.name || !newGoal.targetAmount || !newGoal.deadline) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    const goal: FinancialGoal = {
      id: Date.now().toString(),
      name: newGoal.name,
      targetAmount: Number.parseFloat(newGoal.targetAmount),
      currentAmount: 0,
      deadline: newGoal.deadline,
      category: newGoal.category,
    }

    const updatedGoals = [...financialGoals, goal]
    setFinancialGoals(updatedGoals)
    localStorage.setItem(`goals_${user.id}`, JSON.stringify(updatedGoals))

    setNewGoal({ name: "", targetAmount: "", deadline: "", category: "savings" })
    setShowAddGoal(false)

    toast({
      title: "Goal Added",
      description: "New financial goal created successfully",
    })
  }

  const deleteCategory = (id: string) => {
    const updatedCategories = budgetCategories.filter((cat) => cat.id !== id)
    setBudgetCategories(updatedCategories)
    localStorage.setItem(`budgets_${user.id}`, JSON.stringify(updatedCategories))

    toast({
      title: "Category Deleted",
      description: "Budget category removed successfully",
    })
  }

  const deleteGoal = (id: string) => {
    const updatedGoals = financialGoals.filter((goal) => goal.id !== id)
    setFinancialGoals(updatedGoals)
    localStorage.setItem(`goals_${user.id}`, JSON.stringify(updatedGoals))

    toast({
      title: "Goal Deleted",
      description: "Financial goal removed successfully",
    })
  }

  if (!user) {
    return <div>Loading...</div>
  }

  const totalBudget = budgetCategories.reduce((sum, cat) => sum + cat.limit, 0)
  const totalSpent = budgetCategories.reduce((sum, cat) => sum + cat.spent, 0)

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Budget Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Budget Overview
              </CardTitle>
              <CardDescription>Your monthly spending summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-600">Total Budget</p>
                  <p className="text-2xl font-bold text-blue-800">${totalBudget.toFixed(2)}</p>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <p className="text-sm text-red-600">Total Spent</p>
                  <p className="text-2xl font-bold text-red-800">${totalSpent.toFixed(2)}</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-600">Remaining</p>
                  <p className="text-2xl font-bold text-green-800">${(totalBudget - totalSpent).toFixed(2)}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Overall Progress</span>
                  <span>{((totalSpent / totalBudget) * 100).toFixed(1)}%</span>
                </div>
                <Progress value={(totalSpent / totalBudget) * 100} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Budget Categories */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Budget Categories</CardTitle>
                  <CardDescription>Track spending by category</CardDescription>
                </div>
                <Button onClick={() => setShowAddCategory(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Category
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {showAddCategory && (
                <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                  <h4 className="font-medium mb-3">Add New Category</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="categoryName">Category Name</Label>
                      <Input
                        id="categoryName"
                        value={newCategory.name}
                        onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                        placeholder="e.g., Groceries"
                      />
                    </div>
                    <div>
                      <Label htmlFor="categoryLimit">Monthly Limit ($)</Label>
                      <Input
                        id="categoryLimit"
                        type="number"
                        value={newCategory.limit}
                        onChange={(e) => setNewCategory({ ...newCategory, limit: e.target.value })}
                        placeholder="500"
                      />
                    </div>
                    <div>
                      <Label>Icon</Label>
                      <div className="flex space-x-2 mt-1">
                        {categoryIcons.map((icon) => (
                          <button
                            key={icon}
                            type="button"
                            className={`p-2 rounded border ${newCategory.icon === icon ? "border-blue-500 bg-blue-50" : "border-gray-300"}`}
                            onClick={() => setNewCategory({ ...newCategory, icon })}
                          >
                            {icon}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Color</Label>
                      <div className="flex space-x-2 mt-1">
                        {categoryColors.map((color) => (
                          <button
                            key={color}
                            type="button"
                            className={`w-8 h-8 rounded-full border-2 ${newCategory.color === color ? "border-gray-800" : "border-gray-300"}`}
                            style={{ backgroundColor: color }}
                            onClick={() => setNewCategory({ ...newCategory, color })}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2 mt-4">
                    <Button onClick={addCategory}>Add Category</Button>
                    <Button variant="outline" onClick={() => setShowAddCategory(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {budgetCategories.map((category) => (
                  <div key={category.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="text-xl">{category.icon}</span>
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => deleteCategory(category.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>${category.spent.toFixed(2)} spent</span>
                        <span>${category.limit.toFixed(2)} limit</span>
                      </div>
                      <Progress
                        value={(category.spent / category.limit) * 100}
                        className="h-2"
                        style={{ "--progress-background": category.color } as any}
                      />
                      <div className="text-xs text-gray-600">
                        ${(category.limit - category.spent).toFixed(2)} remaining
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Financial Goals */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Financial Goals
                  </CardTitle>
                  <CardDescription>Track your savings and financial objectives</CardDescription>
                </div>
                <Button onClick={() => setShowAddGoal(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Goal
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {showAddGoal && (
                <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                  <h4 className="font-medium mb-3">Add New Goal</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="goalName">Goal Name</Label>
                      <Input
                        id="goalName"
                        value={newGoal.name}
                        onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                        placeholder="e.g., Emergency Fund"
                      />
                    </div>
                    <div>
                      <Label htmlFor="targetAmount">Target Amount ($)</Label>
                      <Input
                        id="targetAmount"
                        type="number"
                        value={newGoal.targetAmount}
                        onChange={(e) => setNewGoal({ ...newGoal, targetAmount: e.target.value })}
                        placeholder="5000"
                      />
                    </div>
                    <div>
                      <Label htmlFor="deadline">Target Date</Label>
                      <Input
                        id="deadline"
                        type="date"
                        value={newGoal.deadline}
                        onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="goalCategory">Category</Label>
                      <Select
                        value={newGoal.category}
                        onValueChange={(value) => setNewGoal({ ...newGoal, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="savings">Savings</SelectItem>
                          <SelectItem value="travel">Travel</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="investment">Investment</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex space-x-2 mt-4">
                    <Button onClick={addGoal}>Add Goal</Button>
                    <Button variant="outline" onClick={() => setShowAddGoal(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {financialGoals.map((goal) => (
                  <div key={goal.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-medium">{goal.name}</h4>
                        <p className="text-sm text-gray-600">Target: {new Date(goal.deadline).toLocaleDateString()}</p>
                      </div>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => deleteGoal(goal.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>${goal.currentAmount.toFixed(2)} saved</span>
                        <span>${goal.targetAmount.toFixed(2)} target</span>
                      </div>
                      <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="h-2" />
                      <div className="flex justify-between text-xs text-gray-600">
                        <span>{((goal.currentAmount / goal.targetAmount) * 100).toFixed(1)}% complete</span>
                        <span>${(goal.targetAmount - goal.currentAmount).toFixed(2)} remaining</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
