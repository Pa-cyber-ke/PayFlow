"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  CreditCard,
  Send,
  Download,
  History,
  LogOut,
  Eye,
  EyeOff,
  Copy,
  Plus,
  Shield,
  Target,
  BarChart3,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Transaction {
  id: string
  type: "sent" | "received"
  amount: number
  fromAccount: string
  toAccount: string
  description: string
  timestamp: string
  status: "completed" | "pending" | "failed"
}

export default function DashboardPage() {
  const [user, setUser] = useState<any | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [showBalance, setShowBalance] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load transactions
    const allTransactions = JSON.parse(localStorage.getItem("transactions") || "[]")
    const userTransactions = allTransactions.filter(
      (t: Transaction) => t.fromAccount === userData.accountNumber || t.toAccount === userData.accountNumber,
    )
    setTransactions(userTransactions.slice(0, 5)) // Show only recent 5
  }, [router])

  const copyAccountNumber = () => {
    if (user) {
      navigator.clipboard.writeText(user.accountNumber)
      toast({
        title: "Copied!",
        description: "Account number copied to clipboard",
      })
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/")
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">PayFlow</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.firstName}</span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Balance Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Account Balance</CardTitle>
                    <CardDescription>Your current available balance</CardDescription>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setShowBalance(!showBalance)}>
                    {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-gray-900 mb-4">
                  {showBalance ? `$${user.balance.toFixed(2)}` : "••••••"}
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
                  <span>Account: {user.accountNumber}</span>
                  <Button variant="ghost" size="sm" onClick={copyAccountNumber}>
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
                <div className="flex space-x-3">
                  <Link href="/send" className="flex-1">
                    <Button className="w-full">
                      <Send className="w-4 h-4 mr-2" />
                      Send Money
                    </Button>
                  </Link>
                  <Link href="/receive" className="flex-1">
                    <Button variant="outline" className="w-full bg-transparent">
                      <Download className="w-4 h-4 mr-2" />
                      Receive
                    </Button>
                  </Link>
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Money
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Recent Transactions</CardTitle>
                    <CardDescription>Your latest payment activity</CardDescription>
                  </div>
                  <Link href="/transactions">
                    <Button variant="ghost" size="sm">
                      View All
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No transactions yet</p>
                    <p className="text-sm">Start by sending or receiving money</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {transactions.map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              transaction.type === "sent" ? "bg-red-100" : "bg-green-100"
                            }`}
                          >
                            {transaction.type === "sent" ? (
                              <Send className="w-4 h-4 text-red-600" />
                            ) : (
                              <Download className="w-4 h-4 text-green-600" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">
                              {transaction.type === "sent" ? "Sent to" : "Received from"}{" "}
                              {transaction.type === "sent" ? transaction.toAccount : transaction.fromAccount}
                            </p>
                            <p className="text-sm text-gray-500">{transaction.description}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p
                            className={`font-medium ${transaction.type === "sent" ? "text-red-600" : "text-green-600"}`}
                          >
                            {transaction.type === "sent" ? "-" : "+"}${transaction.amount.toFixed(2)}
                          </p>
                          <Badge variant={transaction.status === "completed" ? "default" : "secondary"}>
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/send">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Send className="w-4 h-4 mr-2" />
                    Send Money
                  </Button>
                </Link>
                <Link href="/receive">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Download className="w-4 h-4 mr-2" />
                    Request Money
                  </Button>
                </Link>
                <Link href="/transactions">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <History className="w-4 h-4 mr-2" />
                    Transaction History
                  </Button>
                </Link>
                <Link href="/security">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Shield className="w-4 h-4 mr-2" />
                    Security Settings
                  </Button>
                </Link>
                <Link href="/budget">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Target className="w-4 h-4 mr-2" />
                    Budget & Goals
                  </Button>
                </Link>
                <Link href="/analytics">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Financial Analytics
                  </Button>
                </Link>
                <Link href="/profile">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <LogOut className="w-4 h-4 mr-2" />
                    Profile Settings
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Account Info */}
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Account Holder</p>
                  <p className="font-medium">
                    {user.firstName} {user.lastName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Account Number</p>
                  <p className="font-medium font-mono">{user.accountNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Member Since</p>
                  <p className="font-medium">{new Date(user.createdAt).toLocaleDateString()}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
